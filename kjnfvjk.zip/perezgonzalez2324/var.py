global ui
global calendar
global salir
global acercade
version = "0..0.1rc"

