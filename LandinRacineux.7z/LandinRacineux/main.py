# This is a sample Python script.

import sys

import eventos
from MainWindow import *
from windowsaux import *
import locale
locale.setlocale(locale.LC_TIME, 'es_ES.UTF-8')
locale.setlocale(locale.LC_MONETARY, 'es_ES.UTF-8')



class Main(QtWidgets.QMainWindow):

    def __init__(self):
        super(Main, self).__init__()
        var.ui = Ui_MainWindow()
        var.ui.setupUi(self)
        var.calendar = Calendar()
        var.salir = Salir()
        var.acercaDe = AcercaDe()




        """ 
        Zona de eventos de botones
        """

        var.ui.btnFecha.clicked.connect(eventos.Eventos.abrirCalendar)
        var.ui.btnAlta.clicked.connect(drivers.Drivers.altaDriver)


        """
        Zona de eventos del menubar
        """

        var.ui.actionSalir.triggered.connect(eventos.Eventos.abrirSalir)
        var.ui.actionAcerca_de.triggered.connect(eventos.Eventos.acercade)


        """
        Zona eventos de texto
        """

        var.ui.txtDni.editingFinished.connect(drivers.Drivers.validarDNI)

        var.ui.txtNombre.editingFinished.connect(eventos.Eventos.letraCapital)
        var.ui.txtApel.editingFinished.connect(eventos.Eventos.letraCapital)
        var.ui.txtSalario.editingFinished.connect(eventos.Eventos.letraCapital)

        """
        Zona eventos de toolbar
        """

        var.ui.barSalir.triggered.connect(eventos.Eventos.abrirSalir)
        var.ui.barLimpiar.triggered.connect(drivers.Drivers.limpiaPanel)

        """ 
        Eventos de tablas
        """

        """
        Eventos iniciales
        """
        eventos.Eventos.cargarstatusbar(self)
        eventos.Eventos.cargaprov(self)
        rbtDriver = [var.ui.rbtTodos, var.ui.rbtAlta, var.ui.rbtBaja]
        for i in rbtDriver:
            i.toggled.connect(eventos.Eventos.selEstado)
        eventos.Eventos.resizeTabdrivers(self)


    def closeEvent(self, event):
        mbox = QtWidgets.QMessageBox.information(self,'Salir','Estas seguro que quieres salir?',
                                                 QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        if  mbox == QtWidgets.QMessageBox.StandardButton.Yes:
            app.quit()
        if  mbox == QtWidgets.QMessageBox.StandardButton.No:
            event.ignore()

if __name__ == '__main__':
   app = QtWidgets.QApplication([])
   window = Main()
   window.show()
   sys.exit(app.exec())
