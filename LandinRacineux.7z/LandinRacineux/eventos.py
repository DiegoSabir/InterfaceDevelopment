import locale

import var, sys
from PyQt6 import QtWidgets, QtCore
from datetime import datetime

class Eventos():

    @staticmethod
    def letraCapital(self = None):
        try:
            var.ui.txtApel.setText(var.ui.txtApel.text().title())
            var.ui.txtNombre.setText(var.ui.txtNombre.text().title())
            var.ui.txtSalario.setText(str(locale.currency(float(var.ui.txtSalario.text()))))
        except Exception as error:
            print('error en hacer capital ', error)



    def abrirSalir(self):
        try:
            var.salir.show()

        except Exception as error:
            print('error en abrir salir', error)

    def dniIncorrecto(self):
        var.ui.txtDni.setText(None)
        var.ui.txtDni.setFocus()


    def cerrarSalir(self):
        try:
            var.salir.close()

        except Exception as error:
            print('error en cerrar salir', error)

    def cerrarAcercaDe(self):
        try:
            var.acercaDe.close()

        except Exception as error:
            print('error en cerrar acerca de', error)

    def salir(self):
        try:
            sys.exit(self)
        except Exception as error:
            print(error, "en modulo eventos")

    @staticmethod
    def abrirCalendar(self):
        try:
            var.calendar.show()
        except Exception as error:
            print('error en abrir calendar', error)


    @staticmethod
    def acercade(self):
        try:
            var.acercaDe.show()
        except Exception as error:
            print('error en abrir acercade', error)


    def cargarstatusbar(self):
        try:
            fecha = datetime.now().strftime("%A  -  " + "%d/%m/%Y")
            self.labelstatus = QtWidgets.QLabel(fecha, self)
            self.labelstatus.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)

            version = ("version " + var.version)
            self.statusVersion = QtWidgets.QLabel(version, self)
            self.statusVersion.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)


            var.ui.statusbar.addPermanentWidget(self.labelstatus, 1)
            var.ui.statusbar.addPermanentWidget(self.statusVersion, 0)

        except Exception as error:
            print('Error al cargar statusbar: ', error)

    def cargaprov(self = None):
            try:
                prov = ['A Coruña', 'Lugo', 'Vigo', 'Ferrol', 'Santiago de compostela', 'Ourense', 'Pontevedra']
                var.ui.cmbProvincia.clear()
                var.ui.cmbProvincia.addItem("")
                for i,m in enumerate(prov):
                    var.ui.cmbProvincia.addItem(str(m))

            except Exception as error:
                print('Error al cargar prov: ', error)

    def selEstado(self):
        try:
            if var.ui.rbtTodos.isChecked():
                print("pulsaste todos")
            if var.ui.rbtAlta.isChecked():
                print("pulsaste alta")
            if var.ui.rbtBaja.isChecked():
                print("pulsaste baja")
        except Exception as error:
            print("Error en selEstado", error)

    def resizeTabdrivers(self):
        try:
            header = var.ui.tabDrivers.horizontalHeader()
            for i in range(5):
                if i == 0 or i == 3 or i == 4 or i == 5:
                    header.setSectionResizeMode(i, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
                elif i == 1 or i == 2:
                    header.setSectionResizeMode(i, QtWidgets.QHeaderView.ResizeMode.Stretch)
        except Exception as error:
            print('Error al cargar prov: ', error)